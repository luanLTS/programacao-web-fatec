function validaNumeros(n1, n2) {
    if (isNaN(n1) || n1 === ""){
        alert("informe um número para o primeiro parametro!");
        num1.value = "";
        num1.focus();
        return [0, 0];
    }
    if (isNaN(n2) || n2 === ""){
        alert("informe um número para o segundo parametro!");
        num2.value = "";
        num2.focus();
        return [0, 0];
    }
    return [parseFloat(n1), parseFloat(n2)];
}

function soma()  {
let [n1, n2] = validaNumeros(num1.value, num2.value);
    resultado.value = n1 + n2;
    num1.value = "";
    num2.value = "";
}

function subtracao() {
    let [n1, n2] = validaNumeros(num1.value, num2.value);
    resultado.value = n1 - n2;
    num1.value = "";
    num2.value = "";
}

function divisao() {
    let [n1, n2] = validaNumeros(num1.value, num2.value);
    resultado.value = n1 / n2;
    num1.value = "";
    num2.value = "";
}

function multiplicacao() {
    let [n1, n2] = validaNumeros(num1.value, num2.value);
    resultado.value = n1 * n2;
    num1.value = "";
    num2.value = "";   
}